请把此压缩包解压到main/app内
若出现网络BAD，请修改segatools.ini内的[dns] default=127.0.0.1为你本机的IP地址